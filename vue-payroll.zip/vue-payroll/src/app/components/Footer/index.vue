<template src="./index.tpl.html"></template>
<script>
export default {
    name: 'xc-footer',
    // 验证类型
    props: {},
    data() {
        return {};
    },
    mounted() {},
    methods: {}
};
</script>
<style src="./index.less" lang="less" scoped></style>
