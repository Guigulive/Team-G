/**
 * @file    config
 * @authors 花夏 (liubiao@itoxs.com)
 *
 * @version 1.0.0
 * @date    2017-04-27 16:54:36
 */

let config = {
    ajaxBaseUrl: '/api',
    // 默认 GAS
    GAS: {
        gas: 3000000
    }
};

export default config;
